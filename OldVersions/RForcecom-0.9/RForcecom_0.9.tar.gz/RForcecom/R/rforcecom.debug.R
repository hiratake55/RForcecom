#' @export
##################################
# * for debug use 
##################################
rforcecom.debug <- FALSE

