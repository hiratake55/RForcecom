library(testthat)
library(RForcecom)

test_check("RForcecom")
